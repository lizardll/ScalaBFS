// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read)
//         bit 7  - auto_restart (Read/Write)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0  - Channel 0 (ap_done)
//         bit 1  - Channel 1 (ap_ready)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0  - Channel 0 (ap_done)
//         bit 1  - Channel 1 (ap_ready)
//         others - reserved
// 0x010 : Data signal of csr_c_addr
//         bit 31~0 - csr_c_addr[31:0] (Read/Write)
// 0x014 : reserved
// 0x018 : Data signal of csr_r_addr
//         bit 31~0 - csr_r_addr[31:0] (Read/Write)
// 0x01c : reserved
// 0x020 : Data signal of csc_c_addr
//         bit 31~0 - csc_c_addr[31:0] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of csc_r_addr
//         bit 31~0 - csc_r_addr[31:0] (Read/Write)
// 0x02c : reserved
// 0x030 : Data signal of level_addr
//         bit 31~0 - level_addr[31:0] (Read/Write)
// 0x034 : reserved
// 0x038 : Data signal of node_num
//         bit 31~0 - node_num[31:0] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of push_to_pull_level
//         bit 31~0 - push_to_pull_level[31:0] (Read/Write)
// 0x044 : reserved
// 0x048 : Data signal of pull_to_push_level
//         bit 31~0 - pull_to_push_level[31:0] (Read/Write)
// 0x04c : reserved
// 0x050 : Data signal of axi00_ptr0
//         bit 31~0 - axi00_ptr0[31:0] (Read/Write)
// 0x054 : Data signal of axi00_ptr0
//         bit 31~0 - axi00_ptr0[63:32] (Read/Write)
// 0x058 : reserved
// 0x05c : Data signal of axi01_ptr0
//         bit 31~0 - axi01_ptr0[31:0] (Read/Write)
// 0x060 : Data signal of axi01_ptr0
//         bit 31~0 - axi01_ptr0[63:32] (Read/Write)
// 0x064 : reserved
// 0x068 : Data signal of axi02_ptr0
//         bit 31~0 - axi02_ptr0[31:0] (Read/Write)
// 0x06c : Data signal of axi02_ptr0
//         bit 31~0 - axi02_ptr0[63:32] (Read/Write)
// 0x070 : reserved
// 0x074 : Data signal of axi03_ptr0
//         bit 31~0 - axi03_ptr0[31:0] (Read/Write)
// 0x078 : Data signal of axi03_ptr0
//         bit 31~0 - axi03_ptr0[63:32] (Read/Write)
// 0x07c : reserved
// 0x080 : Data signal of axi04_ptr0
//         bit 31~0 - axi04_ptr0[31:0] (Read/Write)
// 0x084 : Data signal of axi04_ptr0
//         bit 31~0 - axi04_ptr0[63:32] (Read/Write)
// 0x088 : reserved
// 0x08c : Data signal of axi05_ptr0
//         bit 31~0 - axi05_ptr0[31:0] (Read/Write)
// 0x090 : Data signal of axi05_ptr0
//         bit 31~0 - axi05_ptr0[63:32] (Read/Write)
// 0x094 : reserved
// 0x098 : Data signal of axi06_ptr0
//         bit 31~0 - axi06_ptr0[31:0] (Read/Write)
// 0x09c : Data signal of axi06_ptr0
//         bit 31~0 - axi06_ptr0[63:32] (Read/Write)
// 0x0a0 : reserved
// 0x0a4 : Data signal of axi07_ptr0
//         bit 31~0 - axi07_ptr0[31:0] (Read/Write)
// 0x0a8 : Data signal of axi07_ptr0
//         bit 31~0 - axi07_ptr0[63:32] (Read/Write)
// 0x0ac : reserved
// 0x0b0 : Data signal of axi08_ptr0
//         bit 31~0 - axi08_ptr0[31:0] (Read/Write)
// 0x0b4 : Data signal of axi08_ptr0
//         bit 31~0 - axi08_ptr0[63:32] (Read/Write)
// 0x0b8 : reserved
// 0x0bc : Data signal of axi09_ptr0
//         bit 31~0 - axi09_ptr0[31:0] (Read/Write)
// 0x0c0 : Data signal of axi09_ptr0
//         bit 31~0 - axi09_ptr0[63:32] (Read/Write)
// 0x0c4 : reserved
// 0x0c8 : Data signal of axi10_ptr0
//         bit 31~0 - axi10_ptr0[31:0] (Read/Write)
// 0x0cc : Data signal of axi10_ptr0
//         bit 31~0 - axi10_ptr0[63:32] (Read/Write)
// 0x0d0 : reserved
// 0x0d4 : Data signal of axi11_ptr0
//         bit 31~0 - axi11_ptr0[31:0] (Read/Write)
// 0x0d8 : Data signal of axi11_ptr0
//         bit 31~0 - axi11_ptr0[63:32] (Read/Write)
// 0x0dc : reserved
// 0x0e0 : Data signal of axi12_ptr0
//         bit 31~0 - axi12_ptr0[31:0] (Read/Write)
// 0x0e4 : Data signal of axi12_ptr0
//         bit 31~0 - axi12_ptr0[63:32] (Read/Write)
// 0x0e8 : reserved
// 0x0ec : Data signal of axi13_ptr0
//         bit 31~0 - axi13_ptr0[31:0] (Read/Write)
// 0x0f0 : Data signal of axi13_ptr0
//         bit 31~0 - axi13_ptr0[63:32] (Read/Write)
// 0x0f4 : reserved
// 0x0f8 : Data signal of axi14_ptr0
//         bit 31~0 - axi14_ptr0[31:0] (Read/Write)
// 0x0fc : Data signal of axi14_ptr0
//         bit 31~0 - axi14_ptr0[63:32] (Read/Write)
// 0x100 : reserved
// 0x104 : Data signal of axi15_ptr0
//         bit 31~0 - axi15_ptr0[31:0] (Read/Write)
// 0x108 : Data signal of axi15_ptr0
//         bit 31~0 - axi15_ptr0[63:32] (Read/Write)
// 0x10c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFINALBFS_32_CONTROL_ADDR_AP_CTRL                 0x000
#define XFINALBFS_32_CONTROL_ADDR_GIE                     0x004
#define XFINALBFS_32_CONTROL_ADDR_IER                     0x008
#define XFINALBFS_32_CONTROL_ADDR_ISR                     0x00c
#define XFINALBFS_32_CONTROL_ADDR_CSR_C_ADDR_DATA         0x010
#define XFINALBFS_32_CONTROL_BITS_CSR_C_ADDR_DATA         32
#define XFINALBFS_32_CONTROL_ADDR_CSR_R_ADDR_DATA         0x018
#define XFINALBFS_32_CONTROL_BITS_CSR_R_ADDR_DATA         32
#define XFINALBFS_32_CONTROL_ADDR_CSC_C_ADDR_DATA         0x020
#define XFINALBFS_32_CONTROL_BITS_CSC_C_ADDR_DATA         32
#define XFINALBFS_32_CONTROL_ADDR_CSC_R_ADDR_DATA         0x028
#define XFINALBFS_32_CONTROL_BITS_CSC_R_ADDR_DATA         32
#define XFINALBFS_32_CONTROL_ADDR_LEVEL_ADDR_DATA         0x030
#define XFINALBFS_32_CONTROL_BITS_LEVEL_ADDR_DATA         32
#define XFINALBFS_32_CONTROL_ADDR_NODE_NUM_DATA           0x038
#define XFINALBFS_32_CONTROL_BITS_NODE_NUM_DATA           32
#define XFINALBFS_32_CONTROL_ADDR_PUSH_TO_PULL_LEVEL_DATA 0x040
#define XFINALBFS_32_CONTROL_BITS_PUSH_TO_PULL_LEVEL_DATA 32
#define XFINALBFS_32_CONTROL_ADDR_PULL_TO_PUSH_LEVEL_DATA 0x048
#define XFINALBFS_32_CONTROL_BITS_PULL_TO_PUSH_LEVEL_DATA 32
#define XFINALBFS_32_CONTROL_ADDR_AXI00_PTR0_DATA         0x050
#define XFINALBFS_32_CONTROL_BITS_AXI00_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI01_PTR0_DATA         0x05c
#define XFINALBFS_32_CONTROL_BITS_AXI01_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI02_PTR0_DATA         0x068
#define XFINALBFS_32_CONTROL_BITS_AXI02_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI03_PTR0_DATA         0x074
#define XFINALBFS_32_CONTROL_BITS_AXI03_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI04_PTR0_DATA         0x080
#define XFINALBFS_32_CONTROL_BITS_AXI04_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI05_PTR0_DATA         0x08c
#define XFINALBFS_32_CONTROL_BITS_AXI05_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI06_PTR0_DATA         0x098
#define XFINALBFS_32_CONTROL_BITS_AXI06_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI07_PTR0_DATA         0x0a4
#define XFINALBFS_32_CONTROL_BITS_AXI07_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI08_PTR0_DATA         0x0b0
#define XFINALBFS_32_CONTROL_BITS_AXI08_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI09_PTR0_DATA         0x0bc
#define XFINALBFS_32_CONTROL_BITS_AXI09_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI10_PTR0_DATA         0x0c8
#define XFINALBFS_32_CONTROL_BITS_AXI10_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI11_PTR0_DATA         0x0d4
#define XFINALBFS_32_CONTROL_BITS_AXI11_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI12_PTR0_DATA         0x0e0
#define XFINALBFS_32_CONTROL_BITS_AXI12_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI13_PTR0_DATA         0x0ec
#define XFINALBFS_32_CONTROL_BITS_AXI13_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI14_PTR0_DATA         0x0f8
#define XFINALBFS_32_CONTROL_BITS_AXI14_PTR0_DATA         64
#define XFINALBFS_32_CONTROL_ADDR_AXI15_PTR0_DATA         0x104
#define XFINALBFS_32_CONTROL_BITS_AXI15_PTR0_DATA         64

