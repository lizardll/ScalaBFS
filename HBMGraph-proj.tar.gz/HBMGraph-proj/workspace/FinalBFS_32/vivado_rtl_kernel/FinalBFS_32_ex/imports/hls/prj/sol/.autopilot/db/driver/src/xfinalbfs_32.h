// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XFINALBFS_32_H
#define XFINALBFS_32_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfinalbfs_32_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XFinalbfs_32_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XFinalbfs_32;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFinalbfs_32_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFinalbfs_32_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFinalbfs_32_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFinalbfs_32_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XFinalbfs_32_Initialize(XFinalbfs_32 *InstancePtr, u16 DeviceId);
XFinalbfs_32_Config* XFinalbfs_32_LookupConfig(u16 DeviceId);
int XFinalbfs_32_CfgInitialize(XFinalbfs_32 *InstancePtr, XFinalbfs_32_Config *ConfigPtr);
#else
int XFinalbfs_32_Initialize(XFinalbfs_32 *InstancePtr, const char* InstanceName);
int XFinalbfs_32_Release(XFinalbfs_32 *InstancePtr);
#endif

void XFinalbfs_32_Start(XFinalbfs_32 *InstancePtr);
u32 XFinalbfs_32_IsDone(XFinalbfs_32 *InstancePtr);
u32 XFinalbfs_32_IsIdle(XFinalbfs_32 *InstancePtr);
u32 XFinalbfs_32_IsReady(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_EnableAutoRestart(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_DisableAutoRestart(XFinalbfs_32 *InstancePtr);

void XFinalbfs_32_Set_csr_c_addr(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_csr_c_addr(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_csr_r_addr(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_csr_r_addr(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_csc_c_addr(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_csc_c_addr(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_csc_r_addr(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_csc_r_addr(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_level_addr(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_level_addr(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_node_num(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_node_num(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_push_to_pull_level(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_push_to_pull_level(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_pull_to_push_level(XFinalbfs_32 *InstancePtr, u32 Data);
u32 XFinalbfs_32_Get_pull_to_push_level(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi00_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi00_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi01_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi01_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi02_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi02_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi03_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi03_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi04_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi04_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi05_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi05_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi06_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi06_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi07_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi07_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi08_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi08_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi09_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi09_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi10_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi10_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi11_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi11_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi12_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi12_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi13_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi13_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi14_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi14_ptr0(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_Set_axi15_ptr0(XFinalbfs_32 *InstancePtr, u64 Data);
u64 XFinalbfs_32_Get_axi15_ptr0(XFinalbfs_32 *InstancePtr);

void XFinalbfs_32_InterruptGlobalEnable(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_InterruptGlobalDisable(XFinalbfs_32 *InstancePtr);
void XFinalbfs_32_InterruptEnable(XFinalbfs_32 *InstancePtr, u32 Mask);
void XFinalbfs_32_InterruptDisable(XFinalbfs_32 *InstancePtr, u32 Mask);
void XFinalbfs_32_InterruptClear(XFinalbfs_32 *InstancePtr, u32 Mask);
u32 XFinalbfs_32_InterruptGetEnabled(XFinalbfs_32 *InstancePtr);
u32 XFinalbfs_32_InterruptGetStatus(XFinalbfs_32 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
