#include "FinalBFS_32.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void FinalBFS_32::thread_zext_ln133_fu_2483_p1() {
    zext_ln133_fu_2483_p1 = esl_zext<64,13>(i1_0_reg_1578.read());
}

void FinalBFS_32::thread_zext_ln137_fu_2507_p1() {
    zext_ln137_fu_2507_p1 = esl_zext<64,13>(phi_ln137_reg_1589.read());
}

void FinalBFS_32::thread_zext_ln150_fu_2524_p1() {
    zext_ln150_fu_2524_p1 = esl_zext<64,13>(phi_ln150_reg_1600_pp6_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln154_fu_2541_p1() {
    zext_ln154_fu_2541_p1 = esl_zext<64,13>(i2_0_reg_1612.read());
}

void FinalBFS_32::thread_zext_ln158_fu_2565_p1() {
    zext_ln158_fu_2565_p1 = esl_zext<64,13>(phi_ln158_reg_1623.read());
}

void FinalBFS_32::thread_zext_ln171_fu_2582_p1() {
    zext_ln171_fu_2582_p1 = esl_zext<64,13>(phi_ln171_reg_1634_pp9_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln175_fu_2599_p1() {
    zext_ln175_fu_2599_p1 = esl_zext<64,13>(i3_0_reg_1646.read());
}

void FinalBFS_32::thread_zext_ln179_fu_2623_p1() {
    zext_ln179_fu_2623_p1 = esl_zext<64,13>(phi_ln179_reg_1657.read());
}

void FinalBFS_32::thread_zext_ln192_fu_2640_p1() {
    zext_ln192_fu_2640_p1 = esl_zext<64,13>(phi_ln192_reg_1668_pp12_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln196_fu_2657_p1() {
    zext_ln196_fu_2657_p1 = esl_zext<64,13>(i4_0_reg_1680.read());
}

void FinalBFS_32::thread_zext_ln200_fu_2681_p1() {
    zext_ln200_fu_2681_p1 = esl_zext<64,13>(phi_ln200_reg_1691.read());
}

void FinalBFS_32::thread_zext_ln213_fu_2698_p1() {
    zext_ln213_fu_2698_p1 = esl_zext<64,13>(phi_ln213_reg_1702_pp15_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln217_fu_2715_p1() {
    zext_ln217_fu_2715_p1 = esl_zext<64,13>(i5_0_reg_1714.read());
}

void FinalBFS_32::thread_zext_ln221_fu_2739_p1() {
    zext_ln221_fu_2739_p1 = esl_zext<64,13>(phi_ln221_reg_1725.read());
}

void FinalBFS_32::thread_zext_ln234_fu_2756_p1() {
    zext_ln234_fu_2756_p1 = esl_zext<64,13>(phi_ln234_reg_1736_pp18_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln238_fu_2773_p1() {
    zext_ln238_fu_2773_p1 = esl_zext<64,13>(i6_0_reg_1748.read());
}

void FinalBFS_32::thread_zext_ln242_fu_2797_p1() {
    zext_ln242_fu_2797_p1 = esl_zext<64,13>(phi_ln242_reg_1759.read());
}

void FinalBFS_32::thread_zext_ln255_fu_2814_p1() {
    zext_ln255_fu_2814_p1 = esl_zext<64,13>(phi_ln255_reg_1770_pp21_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln259_fu_2831_p1() {
    zext_ln259_fu_2831_p1 = esl_zext<64,13>(i7_0_reg_1782.read());
}

void FinalBFS_32::thread_zext_ln263_fu_2855_p1() {
    zext_ln263_fu_2855_p1 = esl_zext<64,13>(phi_ln263_reg_1793.read());
}

void FinalBFS_32::thread_zext_ln276_fu_2872_p1() {
    zext_ln276_fu_2872_p1 = esl_zext<64,13>(phi_ln276_reg_1804_pp24_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln280_fu_2889_p1() {
    zext_ln280_fu_2889_p1 = esl_zext<64,13>(i8_0_reg_1816.read());
}

void FinalBFS_32::thread_zext_ln284_fu_2913_p1() {
    zext_ln284_fu_2913_p1 = esl_zext<64,13>(phi_ln284_reg_1827.read());
}

void FinalBFS_32::thread_zext_ln297_fu_2930_p1() {
    zext_ln297_fu_2930_p1 = esl_zext<64,13>(phi_ln297_reg_1838_pp27_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln301_fu_2947_p1() {
    zext_ln301_fu_2947_p1 = esl_zext<64,13>(i9_0_reg_1850.read());
}

void FinalBFS_32::thread_zext_ln305_fu_2971_p1() {
    zext_ln305_fu_2971_p1 = esl_zext<64,13>(phi_ln305_reg_1861.read());
}

void FinalBFS_32::thread_zext_ln318_fu_2988_p1() {
    zext_ln318_fu_2988_p1 = esl_zext<64,13>(phi_ln318_reg_1872_pp30_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln322_fu_3005_p1() {
    zext_ln322_fu_3005_p1 = esl_zext<64,13>(i10_0_reg_1884.read());
}

void FinalBFS_32::thread_zext_ln326_fu_3029_p1() {
    zext_ln326_fu_3029_p1 = esl_zext<64,13>(phi_ln326_reg_1895.read());
}

void FinalBFS_32::thread_zext_ln339_fu_3046_p1() {
    zext_ln339_fu_3046_p1 = esl_zext<64,13>(phi_ln339_reg_1906_pp33_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln343_fu_3063_p1() {
    zext_ln343_fu_3063_p1 = esl_zext<64,13>(i11_0_reg_1918.read());
}

void FinalBFS_32::thread_zext_ln347_fu_3087_p1() {
    zext_ln347_fu_3087_p1 = esl_zext<64,13>(phi_ln347_reg_1929.read());
}

void FinalBFS_32::thread_zext_ln360_fu_3104_p1() {
    zext_ln360_fu_3104_p1 = esl_zext<64,13>(phi_ln360_reg_1940_pp36_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln364_fu_3121_p1() {
    zext_ln364_fu_3121_p1 = esl_zext<64,13>(i12_0_reg_1952.read());
}

void FinalBFS_32::thread_zext_ln368_fu_3145_p1() {
    zext_ln368_fu_3145_p1 = esl_zext<64,13>(phi_ln368_reg_1963.read());
}

void FinalBFS_32::thread_zext_ln381_fu_3162_p1() {
    zext_ln381_fu_3162_p1 = esl_zext<64,13>(phi_ln381_reg_1974_pp39_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln385_fu_3179_p1() {
    zext_ln385_fu_3179_p1 = esl_zext<64,13>(i13_0_reg_1986.read());
}

void FinalBFS_32::thread_zext_ln389_fu_3203_p1() {
    zext_ln389_fu_3203_p1 = esl_zext<64,13>(phi_ln389_reg_1997.read());
}

void FinalBFS_32::thread_zext_ln402_fu_3220_p1() {
    zext_ln402_fu_3220_p1 = esl_zext<64,13>(phi_ln402_reg_2008_pp42_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln406_fu_3237_p1() {
    zext_ln406_fu_3237_p1 = esl_zext<64,13>(i14_0_reg_2020.read());
}

void FinalBFS_32::thread_zext_ln410_fu_3261_p1() {
    zext_ln410_fu_3261_p1 = esl_zext<64,13>(phi_ln410_reg_2031.read());
}

void FinalBFS_32::thread_zext_ln423_fu_3278_p1() {
    zext_ln423_fu_3278_p1 = esl_zext<64,13>(phi_ln423_reg_2042_pp45_iter1_reg.read());
}

void FinalBFS_32::thread_zext_ln427_fu_3295_p1() {
    zext_ln427_fu_3295_p1 = esl_zext<64,13>(i15_0_reg_2054.read());
}

void FinalBFS_32::thread_zext_ln431_fu_3319_p1() {
    zext_ln431_fu_3319_p1 = esl_zext<64,13>(phi_ln431_reg_2065.read());
}

}

